/**********************************************************
* PONTIFICIA UNIVERSIDAD JAVERIANA
* Autor: Jorge Andrés Fortich Ordosgoitia
* Sistemas Operativos
* Fecha: 1/10/2024
* Tema: Implementación de un servidor que recibe mensajes 
*       a través de un FIFO (tubería con nombre) y finaliza 
*       cuando se recibe el mensaje "end".
**********************************************************/

#include <stdio.h>      // Para operaciones de entrada/salida estándar como printf y fgets.
#include <sys/stat.h>   // Para manipulación de estados de archivos y directorios, como mknod().
#include <sys/types.h>  // Define tipos de datos para manejo de procesos y archivos.
#include <fcntl.h>      // Proporciona las funciones para abrir archivos (open).
#include <unistd.h>     // Para funciones de bajo nivel como close() y read().
#include <string.h>     // Para funciones de manipulación de cadenas como strcmp().

#define FIFO_FILE "MYFIFO"  // Definición del nombre del archivo FIFO (tubería con nombre).

int main() {
    int ArchivoDesc;      // Descriptor de archivo para manejar el FIFO.
    char BusMensaje[80];  // Buffer para almacenar los mensajes recibidos.
    char final[10];       // Cadena que indica el mensaje para finalizar ("end").
    int fin;              // Indicador para saber si se debe finalizar el servidor.
    int cantidadBytes;    // Almacena la cantidad de bytes leídos del FIFO.

    // Imprime el inicio del servidor.
    printf("\n \t\t >>>>>> INICIO SERVIDOR <<<<<<  \n");

    // Crea el archivo FIFO si no existe.
    mknod(FIFO_FILE, S_IFIFO | 0640, 0);

    // Copia la cadena "end" en la variable final para usarla en la comparación.
    strcpy(final, "end");

    // Bucle infinito que espera recibir mensajes a través del FIFO.
    while (1) {
        // Abre el archivo FIFO en modo lectura.
        ArchivoDesc = open(FIFO_FILE, O_RDONLY);

        // Lee el contenido del FIFO y almacena la cantidad de bytes leídos.
        cantidadBytes = read(ArchivoDesc, BusMensaje, sizeof(BusMensaje));

        // Agrega el carácter nulo ('\0') al final del mensaje para hacerlo una cadena válida.
        BusMensaje[cantidadBytes] = '\0';

        // Imprime el mensaje recibido y el tamaño de bytes leídos.
        printf("Cadena recibida: \"%s\" y cantidad de bytes %d\n", BusMensaje, (int)strlen(BusMensaje));

        // Compara el mensaje recibido con la cadena "end" para ver si debe terminar.
        fin = strcmp(BusMensaje, final);

        // Si el mensaje es "end", cierra el FIFO y termina el bucle.
        if (fin == 0) {
            close(ArchivoDesc);  // Cierra el archivo FIFO.
            break;  // Sale del bucle infinito.
        }
    }

    return 0;  // Finaliza el programa.
}
