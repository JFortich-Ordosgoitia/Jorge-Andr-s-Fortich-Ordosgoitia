/**********************************************************
* PONTIFICIA UNIVERSIDAD JAVERIANA
* Autor: Jorge Andrés Fortich Ordosgoitia
* Sistemas Operativos
* Fecha: 1/10/2024
* Tema: Implementación de un cliente que envía mensajes a 
*       través de un FIFO (tubería con nombre) en un ciclo 
*       infinito hasta que se recibe el mensaje "fin".
**********************************************************/

#include <stdio.h>      // Para operaciones de entrada/salida estándar como printf y fgets.
#include <sys/stat.h>   // Para manipulación de estados de archivos y directorios.
#include <sys/types.h>  // Define tipos de datos como `pid_t` para el manejo de procesos.
#include <fcntl.h>      // Proporciona las funciones de control de archivos, como open().
#include <unistd.h>     // Para funciones de bajo nivel como close() y write().
#include <string.h>     // Para funciones de manipulación de cadenas como strcmp() y strlen().

#define FIFO_FILE "MYFIFO"  // Definición del nombre del archivo FIFO (tubería con nombre).

int main() {
    // Declaración de variables.
    int ArchivoDesc;      // Descriptor de archivo para el FIFO.
    int fin_proceso;      // Indicador para determinar si se debe finalizar el proceso.
    int cadena;           // Almacena el tamaño de la cadena ingresada.
    char BusMensaje[80];  // Buffer para almacenar el mensaje que envía el cliente.
    char senalFin[5];     // Cadena que indica el comando para finalizar ("fin").

    // Imprime mensajes informativos sobre el inicio del cliente.
    printf("\n \t\t >>>>>> INICIO Cliente <<<<<<  \n");
    printf("FIFO_CLIENT: Enviando Mensajes, infinitamente, para finalizar \"end\"\n");

    // Abre el archivo FIFO para escribir. Si no existe, lo crea.
    ArchivoDesc = open(FIFO_FILE, O_CREAT | O_WRONLY);

    // Copia la cadena "fin" a la variable senalFin para usarla como comparación luego.
    strcpy(senalFin, "fin");

    // Bucle infinito para enviar mensajes.
    while (1) {
        // Solicita al usuario que ingrese un mensaje.
        printf("Ingrese mensaje: ");
        
        // Captura el mensaje ingresado por el usuario.
        fgets(BusMensaje, sizeof(BusMensaje), stdin);

        // Calcula la longitud del mensaje ingresado.
        cadena = strlen(BusMensaje);

        // Elimina el carácter de nueva línea (\n) del final del mensaje.
        BusMensaje[cadena - 1] = '\0';

        // Compara el mensaje con la cadena "fin" para determinar si debe finalizar.
        fin_proceso = strcmp(BusMensaje, senalFin);

        // Imprime el resultado de la comparación.
        printf("Final del proceso %d\n", fin_proceso);

        // Si el mensaje no es "fin", lo envía al FIFO.
        if (fin_proceso != 0) {
            // Escribe el mensaje en el archivo FIFO.
            write(ArchivoDesc, BusMensaje, strlen(BusMensaje));
            // Informa que el mensaje ha sido enviado y muestra el tamaño del mensaje.
            printf("Mensaje enviado: \"%s\" y tamaño es %d\n", BusMensaje, (int)strlen(BusMensaje));
        } else {
            // Si el mensaje es "fin", lo envía al FIFO y finaliza el programa.
            write(ArchivoDesc, BusMensaje, strlen(BusMensaje));
            printf("Mensaje enviado: \"%s\" y tamaño es %d\n", BusMensaje, (int)strlen(BusMensaje));
            // Cierra el archivo FIFO.
            close(ArchivoDesc);
            break;  // Sale del bucle infinito y termina el programa.
        }
    }
    
    return 0;  // Finaliza el programa.
}
