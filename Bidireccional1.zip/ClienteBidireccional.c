/**********************************************************
* PONTIFICIA UNIVERSIDAD JAVERIANA
* Autor: Jorge Andrés Fortich Ordosgoitia
* Sistemas Operativos
* Fecha: 1/10/2024
* Tema: Cliente bidireccional que envía y recibe mensajes
*       a través de un FIFO (tubería con nombre).
**********************************************************/

#include<stdio.h>      // Para funciones de entrada/salida estándar como printf.
#include<sys/stat.h>   // Para manipulación de archivos y funciones como mknod.
#include<sys/types.h>  // Tipos de datos como pid_t y otros.
#include<fcntl.h>      // Para funciones de manipulación de archivos como open.
#include<unistd.h>     // Para funciones de bajo nivel como read, write y close.
#include<string.h>     // Para manipulación de cadenas, como strcmp y strcpy.

#define FIFO_FILE "/tmp/fifo_twoway"  // Define el nombre del archivo FIFO.

int main() {
    int fd;                // Descriptor de archivo para el FIFO.
    int end_process;       // Variable para verificar si el proceso debe terminar.
    int stringlen;         // Longitud de la cadena ingresada por el usuario.
    int read_bytes;        // Cantidad de bytes leídos del FIFO.
    char readbuf[80];      // Buffer para almacenar la cadena que se va a leer o escribir.
    char end_str[5];       // Cadena que representa el comando para finalizar ("end").

    // Mensaje de inicio del cliente.
    printf("FIFO_CLIENT: Enviar mensajes, infinitamente. Para terminar, escriba \"end\"\n");

    // Abre o crea el archivo FIFO en modo lectura/escritura.
    fd = open(FIFO_FILE, O_CREAT | O_RDWR);

    // Copia la cadena "end" en la variable end_str para usarla en la comparación.
    strcpy(end_str, "end");

    // Bucle infinito que envía y recibe mensajes a través del FIFO.
    while (1) {
        printf("Ingrese mensaje: ");
        
        // Toma la entrada del usuario.
        fgets(readbuf, sizeof(readbuf), stdin);
        
        // Calcula la longitud de la cadena y elimina el salto de línea.
        stringlen = strlen(readbuf);
        readbuf[stringlen - 1] = '\0';

        // Compara la cadena ingresada con "end" para ver si debe finalizar.
        end_process = strcmp(readbuf, end_str);

        // Si la cadena no es "end", continúa con el envío y recepción de mensajes.
        if (end_process != 0) {
            // Escribe el mensaje en el FIFO.
            write(fd, readbuf, strlen(readbuf));
            printf("FIFOCLIENT: Cadena enviada: \"%s\" y longitud es %d\n", readbuf, (int)strlen(readbuf));

            // Lee la respuesta del servidor.
            read_bytes = read(fd, readbuf, sizeof(readbuf));

            // Termina la cadena leída con '\0' para asegurar que sea válida.
            readbuf[read_bytes] = '\0';

            // Imprime el mensaje recibido.
            printf("FIFOCLIENT: Cadena recibida: \"%s\" y longitud es %d\n", readbuf, (int)strlen(readbuf));

        // Si el mensaje es "end", termina el proceso.
        } else {
            // Envía el mensaje final "end" antes de cerrar.
            write(fd, readbuf, strlen(readbuf));
            printf("FIFOCLIENT: Cadena enviada: \"%s\" y longitud es %d\n", readbuf, (int)strlen(readbuf));

            // Cierra el descriptor de archivo FIFO y finaliza.
            close(fd);
            break;
        }
    }

    return 0;  // Finaliza el programa.
}
