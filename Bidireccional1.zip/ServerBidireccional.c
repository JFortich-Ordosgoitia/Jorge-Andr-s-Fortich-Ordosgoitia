/**********************************************************
* PONTIFICIA UNIVERSIDAD JAVERIANA
* Autor: Jorge Andrés Fortich Ordosgoitia
* Sistemas Operativos
* Fecha: 1/10/2024
* Tema: Servidor bidireccional que recibe mensajes, 
*       invierte la cadena y envía la respuesta 
*       a través de un FIFO (tubería con nombre).
**********************************************************/

#include<stdio.h>      // Para funciones estándar de entrada/salida como printf.
#include<sys/stat.h>   // Para manejo de archivos y directorios, como mkfifo.
#include<sys/types.h>  // Para tipos de datos como pid_t, etc.
#include<fcntl.h>      // Para operaciones con archivos, como open.
#include<unistd.h>     // Para funciones de bajo nivel como read, write, sleep.
#include<string.h>     // Para funciones de manejo de cadenas, como strcpy, strlen.

#define FIFO_FILE "/tmp/fifo_twoway"  // Define el archivo FIFO.

void reverse_string(char *str);  // Prototipo de función para invertir cadenas.

int main() {
    int fd;                 // Descriptor de archivo para el FIFO.
    char readbuf[80];       // Buffer para almacenar la cadena recibida.
    char end[10];           // Cadena para detectar el final ("end").
    int to_end;             // Variable para verificar si el mensaje es "end".
    int read_bytes;         // Almacena la cantidad de bytes leídos del FIFO.

    // Crea el archivo FIFO si no existe.
    mkfifo(FIFO_FILE, S_IFIFO | 0640);

    // Copia la cadena "end" en la variable end.
    strcpy(end, "end");

    // Abre el archivo FIFO en modo lectura/escritura.
    fd = open(FIFO_FILE, O_RDWR);

    // Bucle que maneja la recepción y envío de mensajes.
    while (1) {
        // Lee el mensaje enviado a través del FIFO.
        read_bytes = read(fd, readbuf, sizeof(readbuf));

        // Agrega un terminador nulo ('\0') al final de la cadena leída.
        readbuf[read_bytes] = '\0';

        // Imprime el mensaje recibido y su longitud.
        printf("FIFOSERVER: Cadena recibida: \"%s\" y longitud es %d\n", readbuf, (int)strlen(readbuf));

        // Compara el mensaje recibido con "end" para ver si debe finalizar.
        to_end = strcmp(readbuf, end);

        // Si el mensaje es "end", cierra el FIFO y finaliza el programa.
        if (to_end == 0) {
            close(fd);  // Cierra el descriptor de archivo FIFO.
            break;      // Sale del bucle infinito.
        }

        // Invierte la cadena recibida.
        reverse_string(readbuf);

        // Imprime la cadena invertida y su longitud.
        printf("FIFOSERVER: Enviando cadena invertida: \"%s\" y longitud es %d\n", readbuf, (int)strlen(readbuf));

        // Envía la cadena invertida de vuelta a través del FIFO.
        write(fd, readbuf, strlen(readbuf));

        // Pausa el proceso para asegurar que el cliente pueda leer el mensaje antes de que el servidor lo vuelva a leer.
        sleep(2);
    }

    return 0;  // Finaliza el programa.
}

// Función que invierte una cadena.
void reverse_string(char *str) {
    int last, limit, first;
    char temp;

    // Calcula el índice del último carácter de la cadena.
    last = strlen(str) - 1;

    // Calcula el límite hasta el que se debe invertir (mitad de la cadena).
    limit = last / 2;

    // Inicializa el índice del primer carácter.
    first = 0;

    // Bucle para intercambiar los caracteres de los extremos hacia el centro.
    while (first < last) {
        temp = str[first];
        str[first] = str[last];
        str[last] = temp;
        first++;
        last--;
    }

    return;  // Finaliza la función.
}

